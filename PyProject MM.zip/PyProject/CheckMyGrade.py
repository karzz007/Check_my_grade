import time
import csv
import statistics

class Node:
    def __init__(self, student):
        self.student = student
        self.next = None

class Student:
    def __init__(self, email, password, first_name, last_name, course, professor, grade):
        self.email = email
        self.password = password
        self.first_name = first_name
        self.last_name = last_name
        self.course = course
        self.professor = professor
        self.grade = float(grade)

    def display_details(self):
        return f"{self.first_name} {self.last_name} ({self.email}) - Course: {self.course}, Professor: {self.professor}, Grade: {self.grade}"

class StudentManager:
    def __init__(self):
        self.head = None
        self.load_from_csv()

    def add_student(self, email, password, first_name, last_name, course, professor, grade):
        new_student = Student(email, password, first_name, last_name, course, professor, grade)
        new_node = Node(new_student)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        self.save_to_csv()

    def delete_student(self, email):
        current, prev = self.head, None
        while current:
            if current.student.email == email:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                self.save_to_csv()
                return
            prev, current = current, current.next

    def modify_student(self, email, new_first_name, new_last_name, new_course, new_professor, new_grade):
        current = self.head
        while current:
            if current.student.email == email:
                current.student.first_name = new_first_name
                current.student.last_name = new_last_name
                current.student.course = new_course
                current.student.professor = new_professor
                current.student.grade = float(new_grade)
                self.save_to_csv()
                return
            current = current.next

    def search(self):
        columns = ["email", "first_name", "last_name", "course", "professor"]
        print("\nSearch by:")
        for i, col in enumerate(columns, 1):
            print(f"{i}. {col.capitalize()}")
        choice = input("Enter your choice: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(columns):
            selected_column = columns[int(choice) - 1]
            query = input(f"Enter {selected_column}: ").strip().lower()
            start_time = time.time()
            results = []
            current = self.head
            while current:
                if query in getattr(current.student, selected_column).lower():
                    results.append(current.student)
                current = current.next
            end_time = time.time()
            for student in results:
                print(student.display_details())
            print(f"Search completed in {end_time - start_time:.6f} seconds.")

    def sort_students(self):
        students = []
        current = self.head
        while current:
            students.append(current.student)
            current = current.next
        print("\nSort by: \n1. Name\n2. Grade")
        choice = input("Enter your choice: ").strip()
        if choice == "1":
            students.sort(key=lambda x: (x.first_name, x.last_name))
        elif choice == "2":
            students.sort(key=lambda x: x.grade, reverse=True)
        for student in students:
            print(student.display_details())

    def calculate_statistics(self):
        courses = {}
        current = self.head
        while current:
            course = current.student.course
            grade = current.student.grade
            if course not in courses:
                courses[course] = []
            courses[course].append(grade)
            current = current.next
        for course, grades in courses.items():
            print(f"{course}: Avg: {statistics.mean(grades):.2f}, Median: {statistics.median(grades):.2f}")

    def report(self):
        print("\nReport Type: \n1. Course-wise\n2. Professor-wise\n3. Student-wise")
        choice = input("Enter your choice: ").strip()
        key_func = "course" if choice == "1" else "professor" if choice == "2" else "email"
        report_data = {}
        current = self.head
        while current:
            key = getattr(current.student, key_func)
            if key not in report_data:
                report_data[key] = []
            report_data[key].append(current.student.display_details())
            current = current.next
        for key, details in report_data.items():
            print(f"\n{key}:")
            for detail in details:
                print(f"   {detail}")

    def save_to_csv(self):
        with open("students.csv", "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["email", "password", "first_name", "last_name", "course", "professor", "grade"])
            current = self.head
            while current:
                student = current.student
                writer.writerow([student.email, student.password, student.first_name, student.last_name, student.course, student.professor, student.grade])
                current = current.next

    def load_from_csv(self):
        try:
            with open("students.csv", "r") as file:
                reader = csv.reader(file)
                next(reader, None)
                for row in reader:
                    if row:
                        self.add_student(*row)
        except FileNotFoundError:
            pass

class CheckMyGradeApp:
    def __init__(self):
        self.students = StudentManager()

    def menu(self):
        while True:
            print("\nCheckMyGrade Menu")
            print("1. Add Student\n2. Delete Student\n3. Modify Student\n4. Search Students\n5. Sort Students\n6. Calculate Statistics\n7. View Report\n8. Exit")
            choice = input("Enter your choice: ").strip()
            if choice == "1":
                self.students.add_student(input("Email: "), input("Password: "), input("First Name: "), input("Last Name: "), input("Course: "), input("Professor: "), input("Grade: "))
            elif choice == "2":
                self.students.delete_student(input("Enter email to delete: "))
            elif choice == "3":
                self.students.modify_student(input("Email: "), input("New First Name: "), input("New Last Name: "), input("New Course: "), input("New Professor: "), input("New Grade: "))
            elif choice == "4":
                self.students.search()
            elif choice == "5":
                self.students.sort_students()
            elif choice == "6":
                self.students.calculate_statistics()
            elif choice == "7":
                self.students.report()
            elif choice == "8":
                break
if __name__ == "__main__":
    CheckMyGradeApp().menu()
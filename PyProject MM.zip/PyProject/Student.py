import pandas as pd
from faker import Faker
import random

fake = Faker()

num_records = 1000

data = {
    "Email_address": [fake.email() for _ in range(num_records)],
    "First_name": [fake.first_name() for _ in range(num_records)],
    "Last_name": [fake.last_name() for _ in range(num_records)],
    "Course.id": [f"DATA{random.randint(100, 500)}" for _ in range(num_records)],
    "grades": [random.choice(['A', 'B', 'C', 'D', 'F']) for _ in range(num_records)],
    "Marks": [random.randint(0, 100) for _ in range(num_records)]
}

df = pd.DataFrame(data)

df.to_csv("Student.csv", index=False)

print("CSV file 'Student.csv' generated successfully with 1000 records!")

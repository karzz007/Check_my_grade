import pandas as pd
import hashlib
from faker import Faker

fake = Faker()

def generate_login_csv(num_records=10):
    data = {
        "User_id": [],
        "Password": [],
        "Role": []
    }


    data["User_id"].append("micheal@mycsu.edu")
    password = "Welcome12#_"
    encrypted_password = hashlib.sha256(password.encode()).hexdigest()
    data["Password"].append(encrypted_password)
    data["Role"].append("professor")


    for _ in range(num_records - 1): 
        user_id = fake.email()
        password = fake.password(length=12, special_chars=True, digits=True, upper_case=True, lower_case=True)
        encrypted_password = hashlib.sha256(password.encode()).hexdigest()
        data["User_id"].append(user_id)
        data["Password"].append(encrypted_password)
        data["Role"].append(fake.random_element(elements=("professor", "student")))

    df = pd.DataFrame(data)
    df.to_csv("Login.csv", index=False)
    print("Login.csv generated successfully!")

if __name__ == "__main__":
    generate_login_csv()

import pandas as pd
from faker import Faker
import random

fake = Faker()

def generate_course_data(num_courses=20):
    course_data = {
        "Course_id": [f"DATA{random.randint(100, 600)}" for _ in range(num_courses)],
        "Course_name": [fake.catch_phrase() for _ in range(num_courses)],
        "Description": [fake.paragraph(nb_sentences=2) for _ in range(num_courses)]
    }
  
    course_data["Course_id"][0] = "DATA200"
    course_data["Course_name"][0] = "Data Science"
    course_data["Description"][0] = "Provides insight about DS and Python"
    return course_data

course_data = generate_course_data()
df_courses = pd.DataFrame(course_data)
df_courses.to_csv("Course.csv", index=False)
print("CSV file 'Course.csv' generated successfully!")
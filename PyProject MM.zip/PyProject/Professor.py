from faker import Faker
import pandas as pd
import random

fake = Faker()

num_professors = 10
professor_data = {
    "Professor_id": [fake.email() for _ in range(num_professors)],
    "Professor_Name": [fake.name() for _ in range(num_professors)],
    "Rank": [random.choice(["Assistant Professor", "Associate Professor", "Professor"]) for _ in range(num_professors)],
    "Course.id": [f"DATA{random.randint(100, 600)}" for _ in range(num_professors)]
}

df_professors = pd.DataFrame(professor_data)
df_professors.to_csv("Professor.csv", index=False)
print("CSV file 'Professor.csv' generated successfully!")
